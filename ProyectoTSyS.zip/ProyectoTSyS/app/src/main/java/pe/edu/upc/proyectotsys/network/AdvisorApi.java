package pe.edu.upc.proyectotsys.network;

public class AdvisorApi {
    private static String BASE_URL = "http://t-sys-kennygonzales.c9users.io/";
}
